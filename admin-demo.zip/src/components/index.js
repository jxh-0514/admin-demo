import ThemePicker from './ThemePicker'
import ScreenFull from './ScreenFull'
Vue.component('ThemePicker', ThemePicker) //全局主题选择器
Vue.component('ScreenFull', ScreenFull) // 全屏组件
