<template>
  <div class="app-container">
    11233
  </div>
</template>

<script>
export default {
  name: 'DirectivePermission',
  data() {
    return {
    
    }
  },
}
</script>

<style lang="scss" scoped>


</style>