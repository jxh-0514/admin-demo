<template>
  <div class="app-container">
   36699
  </div>
</template>

<script>
export default {
  name: 'PagePermission',
  methods: {
   
  }
}
</script>
