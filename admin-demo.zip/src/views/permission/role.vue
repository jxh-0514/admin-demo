<template>
  <div class="app-container">
    56666
  </div>
</template>

<script>
const defaultRole = {
  key: '',
  name: '',
  description: '',
  routes: []
}

export default {
  data() {
    return {}
  },
  computed: {
    routesData() {
      return this.routes
    }
  },
  created() {
  

  },
}
</script>

<style lang="scss" scoped>

</style>
