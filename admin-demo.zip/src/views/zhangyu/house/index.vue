<!--
    vue嵌套路由
    需要一个router-view中转页面，子路由须加上router-view
-->
<template>
  <div>
      <router-view />
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>